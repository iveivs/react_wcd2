function Header () {
    return <h1>Counter</h1>
}

export default Header