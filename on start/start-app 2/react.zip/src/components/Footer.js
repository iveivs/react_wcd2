const Footer = () => {
    return (
      <footer>
        <input type="text" placeholder="Новая задача" />
            <input type="submit" value="Добавить" />
      </footer>
    )
}

export default Footer

