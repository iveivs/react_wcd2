const UserLogin = () => {
    return <a href="http://google.com">Log in</a>
  }


export default UserLogin