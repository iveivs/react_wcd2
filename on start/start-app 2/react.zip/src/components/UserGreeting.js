const UserGreeting = (props) => {
    return <p>Hello, {props.name} , {props.lastname}</p>
  }

  export default UserGreeting