import Header from './Header';
import UserLogin from './UserLogin';
import UserGreeting from './UserGreeting';
import List from './List';
import Footer from './Footer';
import "./App.css "

const App = () => {
    const isLoggedIn = true
    const someLastname = "Smith"
    return (
        <div className='app'>
            {isLoggedIn ? <UserGreeting name="John !!!" lastname={someLastname} /> : <UserLogin />}
            <UserLogin />
            <Header />
            <List ></List>
            <Footer />
        </div>
    )
}

export default App