import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

const Form = ({temp, tempUser}) => {
	const [name, setDataForm] = useState()
	console.log(name);

	useEffect(()=>{
		setDataForm()
	}, [name])
	

	const handleSubmit = (e) => {
        e.preventDefault();
		
	}
	
	const showInput = (event) => {
		console.log(event.target.value);
	}

	useEffect(()=> {
		document.body.className = "with-nav radial-bg flex-center"
	})
    return (
        <div className="white-plate white-plate--payment">
            <div className="container-fluid">
                <div className="white-plate__header text-center">
                    <p className="white-plate__logo">
                        <span>Форма</span> заявок
                    </p>
                </div>

                <div className="white-plate__line-between white-plate__line-between--main"></div>

                <form id="form" method="POST" action="">
                    <label>Ваши данные:</label>
                    <div className="form-group">
                        <input
							
                            id="name"
                            type="text"
                            name="name"
                            autoComplete="on"
                            className="form-control"
                            placeholder="Имя и Фамилия"
							value={tempUser.name}
                            required
							onChange={(e) => {showInput(e)}}
                        />
                    </div>
                    <div className="form-group">
                        <input
                            id="phone"
                            type="text"
                            name="phone"
                            autoComplete="on"
                            className="form-control"
                            placeholder="Телефон"
							value={tempUser.phone}
							onChange={(e) => {setDataForm(e.target.value)}}
                        />
                    </div>
                    <div className="form-group">
                        <input
                            id="email"
                            type="email"
                            name="email"
                            autoComplete="on"
                            className="form-control"
                            placeholder="Email"
							value={tempUser.email}
							onChange={(e) => {showInput(e)}}
                            required
                        />
                    </div>
                    <div className="form-group">
                        <label htmlFor="exampleFormControlSelect1">Продукт:</label>
                        <select
                            id="product"
                            name="product"
                            className="form-control"
                        >
                            <option value="course-html">Курс по верстке</option>
                            <option value="course-js">
                                Курс по JavaScript
                            </option>
                            <option value="course-vue">Курс по VUE JS</option>
                            <option value="course-php">Курс по PHP</option>
                            <option value="course-wordpress">
                                Курс по WordPress
                            </option>
                        </select>
                    </div>
                    <div className="form-group">
                        <button 
							onClick={(e)=>{handleSubmit(e)}}
                            className="btn btn-lg btn-primary btn-block"
                        >
                            Оформить заявку
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default Form;