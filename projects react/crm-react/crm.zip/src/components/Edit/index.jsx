const Edit = () => {
    return ( 
        <div>
            <h1>Edit</h1>
        </div>
     );
}
 
export default Edit;