const Tab = () => {
    return ( 
        <div>
            <h1>Tab</h1>
        </div>
     );
}
 
export default Tab;