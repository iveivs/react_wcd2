// import { Route, Routes} from "react-router-dom";
import Form from '../Form';
import Header from '../Header';
import Tab from "../Tab";
import Edit from "../Edit";
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import { useState } from 'react';
import { useEffect } from 'react';

function App() {
  const [users, setUsers] = useState(
    [
        {id: 1, name: 'name1', phone: 111222, email: 'name1@name.name', product: "course-js"},
        {id: 2, name: 'name2', phone: 222444, email: 'name2@name.name', product: "course-php"},
        {id: 3, name: 'name3', phone: 333666, email: 'name3@name.name', product: "course-html"},
        {id: 4, name: 'name4', phone: 444444, email: 'name4@name.name', product: "course-js"},
        {id: 5, name: 'name5', phone: 555444, email: 'name5@name.name', product: "course-html"}
    ]
  )
  const temp = () => {
    return users[Math.floor(Math.random() * users.length)]
  } 
  
  const [tempUser, setTempUser] = useState(temp())
  console.log(tempUser);

  return (
    <div className="App">
      <Router>
      <Header/>
      <Routes>
          <Route path="/" element={<Form temp={temp} tempUser={tempUser}/>} />
          <Route path="/tab" element={< Tab/>} />
          <Route path="/edit" element={< Edit/>} />
      </Routes>
      </Router>
    </div>
  );
}

export default App;
