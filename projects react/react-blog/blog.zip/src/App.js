import Navbar from './Navbar'
import Home from './Home'
import Create from './Create';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'

function App() {
  return (
    <Router>
        <div className="app">
        < Navbar/>
        <main className="main">
          <Routes>
            <Route path="/" element={<Home/>}></Route>
            <Route path="/create" element={<Create/>}></Route>
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
