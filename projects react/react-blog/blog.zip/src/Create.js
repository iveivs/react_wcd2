const Create = () => {
    return ( 
        <div className="create">
            <h2>Add a new post</h2>
        </div>
     );
}
 
export default Create;